package com.davivienda.factoraje.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.Permissions.PermissionRequestDTO;
import com.davivienda.factoraje.domain.dto.Permissions.PermissionResponseDTO;
import com.davivienda.factoraje.service.PermissionService;

@RestController
@RequestMapping("/api/permissions")
public class PermissionController {

    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<PermissionResponseDTO>> getPermissions() {
        return ResponseEntity.ok(permissionService.getPermissions());   
    }

    @PostMapping("/create")
    public ResponseEntity<PermissionResponseDTO> createPermission(@RequestBody PermissionRequestDTO permissionRequestDTO) {
        
        return ResponseEntity.ok(permissionService.createPermission(permissionRequestDTO));
    }
    
}
