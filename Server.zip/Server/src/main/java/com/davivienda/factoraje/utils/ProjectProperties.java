package com.davivienda.factoraje.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProjectProperties {

    @Value("${codigo.app.entorno}")
    private String codigoAppEntorno;

    @Value("${nombre.jndy}")
    private String nombreJNDY;

    @Value("${fabrica.default}")
    private String fabricaDefault;

    @Value("${servicio.default}")
    private String servicioDefault;

    public String getCodigoAppEntorno() {
        return codigoAppEntorno;
    }

    public String getNombreJNDY() {
        return nombreJNDY;
    }

    public String getFabricaDefault() {
        return fabricaDefault;
    }

    public String getServicioDefault() {
        return servicioDefault;
    }
}