package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors; // Importación necesaria para Collectors

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.repository.EntityRepository;

@Service
public class EntityService {

    private final EntityRepository entityRepository;

    public EntityService(EntityRepository entityRepository) {
        this.entityRepository = entityRepository;
    }

    public EntityModel createEntity(EntityModel entity) {
        return entityRepository.save(entity);
    }

    public List<EntityModel> getEntities() {
        return entityRepository.findAll();
    }

    public List<EntityModel> getEntitiesByType(boolean isEntityType) {
        // Corregido .toList() por .collect(Collectors.toList()) para compatibilidad con Java 8
        return entityRepository.findAll().stream()
                .filter(entity -> entity.getEntityType() == isEntityType)
                .collect(Collectors.toList());
    }

    public EntityModel findByCode(String code) {
        return entityRepository.findAll().stream()
                .filter(entity -> entity.getCode().equals(code))
                .findFirst()
                .orElse(null);
    }

    public EntityModel getEntityById(UUID id) {
        return entityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Entity not found"));
    }

    public EntityModel updateEntity(UUID id, EntityModel entity) {

        if (!entityRepository.existsById(id)) {
            throw new RuntimeException("Entity not found");
        }

        EntityModel existingEntity = entityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Entity not found"));

        existingEntity.setCode(entity.getCode());
        existingEntity.setName(entity.getName());
        existingEntity.setNit(entity.getNit());
        existingEntity.setAccountBank(entity.getAccountBank());
        existingEntity.setEmail(entity.getEmail());

        return entityRepository.save(existingEntity);
    }

    public void deleteEntity(UUID id) {
        if (!entityRepository.existsById(id)) {
            throw new RuntimeException("Entity not found");
        }
        entityRepository.deleteById(id);
    }
}
