package com.davivienda.factoraje.domain.dto.Auth;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

import com.davivienda.factoraje.domain.model.RoleModel;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserLoggedDTOResponse {

    private UUID id;
    private String userName;
    private String email;
    private String dui;
    private UUID entityId;
    private String entityName;
    private List<RoleModel> roles;
}