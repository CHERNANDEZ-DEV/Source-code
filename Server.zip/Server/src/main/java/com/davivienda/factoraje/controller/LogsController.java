package com.davivienda.factoraje.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/logs")
@Slf4j
public class LogsController {

    @GetMapping("/info")
    public ResponseEntity<?> getInfoLogs() {
        log.info("Este es un mensaje de log de nivel INFO");
        return ResponseEntity.ok("Logs de nivel INFO generados correctamente");
    }

    @GetMapping("/error")
    public ResponseEntity<?> getErrorLogs() {
        log.error("Este es un mensaje de log de nivel ERROR");
        return ResponseEntity.ok("Logs de nivel ERROR generados correctamente");
    }

    @GetMapping("/debug")
    public ResponseEntity<?> getDebugLogs() {
        log.debug("Este es un mensaje de log de nivel DEBUG");
        return ResponseEntity.ok("Logs de nivel DEBUG generados correctamente");
    }
    
}
