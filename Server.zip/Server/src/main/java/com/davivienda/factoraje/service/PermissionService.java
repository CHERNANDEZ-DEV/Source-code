package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors; // Importación necesaria

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.Permissions.PermissionRequestDTO;
import com.davivienda.factoraje.domain.dto.Permissions.PermissionResponseDTO;
import com.davivienda.factoraje.domain.model.PermissionModel;
import com.davivienda.factoraje.repository.PermissionRepository;

@Service
public class PermissionService {

    private final PermissionRepository permissionRepository;

    public PermissionService(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
    }

    public PermissionModel getPermissionById(UUID permissionId) {
        
        PermissionModel permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new RuntimeException("Permission not found"));

        return permission;
    }

    public List<PermissionResponseDTO> getPermissions() {
        
        List<PermissionModel> permissions = permissionRepository.findAll();
        
        // Corregido .toList() por .collect(Collectors.toList()) para compatibilidad con Java 8
        List<PermissionResponseDTO> responseDTOs = permissions.stream()
                .map(permission -> {
                    PermissionResponseDTO dto = new PermissionResponseDTO();
                    dto.setPermission_id(permission.getPermission_id());
                    dto.setPermissionName(permission.getPermissionName());
                    dto.setPermissionDescription(permission.getPermissionDescription());
                    return dto;
                })
                .collect(Collectors.toList());
        
        return responseDTOs;
    }

    public PermissionResponseDTO createPermission(PermissionRequestDTO permissionRequestDTO) {

        PermissionModel permissionModel = new PermissionModel();
        PermissionResponseDTO responseDTO = new PermissionResponseDTO();

        permissionModel.setPermissionName(permissionRequestDTO.getPermissionName());
        permissionModel.setPermissionDescription(permissionRequestDTO.getPermissionDescription());

        PermissionModel response = permissionRepository.save(permissionModel);

        if (response != null) {

            responseDTO.setPermission_id(response.getPermission_id());
            responseDTO.setPermissionName(response.getPermissionName());
            responseDTO.setPermissionDescription(response.getPermissionDescription());

        }

        return responseDTO;

    }

}
