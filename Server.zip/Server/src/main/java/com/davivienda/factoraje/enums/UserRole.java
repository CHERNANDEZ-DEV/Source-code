package com.davivienda.factoraje.enums;

public enum UserRole {
    MANAGER,
    OPERATOR,
    AUTHORIZING
}
