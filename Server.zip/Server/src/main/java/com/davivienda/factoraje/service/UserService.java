package com.davivienda.factoraje.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors; // Importación necesaria para Collectors

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.Users.AssignRolesToUserRequestDTO;
import com.davivienda.factoraje.domain.dto.Users.CreateAdminRequestDTO;
import com.davivienda.factoraje.domain.dto.Users.CreateAdminResponseDTO;
import com.davivienda.factoraje.domain.model.RoleModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final RoleService roleService;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, RoleService roleService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.roleService = roleService;
    }

    public List<UserModel> getAll() {
        return userRepository.findAll();
    }

    public UserModel createPayer(UserModel payer) {
    
        // Assign the "PAYER" role to the user
        RoleModel payerRole = roleService.getRoleByName("PAYER");
        
        if (payerRole == null) {
            throw new RuntimeException("PAYER role not found");
        }

        // Add the payer role to the user
        payer.getRoles().add(payerRole);

        return userRepository.save(payer);
    }

    public List<UserModel> getPayers() {

        List<UserModel> users = userRepository.findAll();
        // Corregido .toList() por .collect(Collectors.toList()) para compatibilidad con Java 8
        List<UserModel> payers = users.stream()
                .filter(user -> user.getRoles().stream()
                        .anyMatch(role -> role.getRoleName().equals("PAYER")))
                .collect(Collectors.toList());
        return payers;
    }

    public UserModel findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public UserModel save(UserModel user) {

        return userRepository.save(user);
    }

    public boolean checkPassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    // public LoginDTOResponse loginAdmin(LoginAdminRequestDTO admin) {

    // UserModel user = userRepository.findByEmail(admin.getEmail());
    // if (user == null) {
    // throw new RuntimeException("User not found");
    // }

    // if (!checkPassword(admin.getPassword(), user.getPassword())) {
    // throw new RuntimeException("Invalid credentials");
    // }

    // return new LoginDTOResponse(user.getId(), user.getEmail(), user.getRoles());
    // }

    public CreateAdminResponseDTO registerAdmin(CreateAdminRequestDTO admin) {

        UserModel user = new UserModel();
        user.setName(admin.getName());
        user.setEmail(admin.getEmail());
        // Encode the password before saving
        if (admin.getPassword() == null || admin.getPassword().isEmpty()) {
            
        } else {
            
        }

        UserModel savedUser = userRepository.save(user);

        return new CreateAdminResponseDTO(savedUser.getName(), savedUser.getEmail());
    }

    // public UserModel findByCode(String code) {
    // 	return userRepository.findByCode(code);
    // }

    public UserModel getUserById(UUID id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public UserModel assignRolesToUser(AssignRolesToUserRequestDTO assignRolesToUserRequestDTO) {

        UserModel user = userRepository.findById(assignRolesToUserRequestDTO.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        for (UUID roleId : assignRolesToUserRequestDTO.getRoleIds()) {

            RoleModel role = roleService.getRoleById(roleId);

            if (role != null) {
                user.getRoles().add(role);
            } else {
                throw new RuntimeException("Role with ID " + roleId + " not found");
            }
        }

        UserModel updatedUser = userRepository.save(user);

        return updatedUser;
    }

    public UserModel findByEmailAndPassword(String email, String password) {
        UserModel user = userRepository.findByEmail(email);

        return null;
    }

    public Optional<UserModel> findUserByDUI(String dui) {
        return userRepository.findByDui(dui);
    }

}
