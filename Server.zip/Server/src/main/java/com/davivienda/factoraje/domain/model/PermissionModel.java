package com.davivienda.factoraje.domain.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.hibernate.annotations.GenericGenerator; // Importación para Hibernate 5

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

// Importaciones corregidas para Spring Boot 2 (javax)
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue; // Importación necesaria
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "permissions")
public class PermissionModel {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
        name = "UUID",
        strategy = "org.hibernate.id.UUIDGenerator"
    )
    @Column(name = "permission_id", columnDefinition = "UUID", updatable = false, nullable = false)
    private UUID permission_id;

    @Column(nullable = false, unique = true)
    @NotBlank(message = "Permission name cannot be blank")
    private String permissionName;

    @Column(nullable = false, length = 255)
    @NotBlank(message = "Permission description cannot be blank, must be less than 255 characters")
    private String permissionDescription;

    @JsonIgnore
    @ManyToMany(mappedBy = "permisos", fetch = FetchType.LAZY)
    private Set<RoleModel> roles = new HashSet<>();
}
