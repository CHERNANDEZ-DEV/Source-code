package com.davivienda.factoraje.constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PermissionsConstants {

    private String GET_AGREEMENTS = "GET_AGREEMENTS";
    private String VIEW_AGREEMENTS = "VIEW_AGREEMENTS";
    private String UPDATE_AGREEMENT = "UPDATE_AGREEMENT";

    private String UPLOAD_FILE = "UPLOAD_FILE";

    private String SELECT_DOCUMENTS = "SELECT_DOCUMENTS";
    private String APPROVE_DOCUMENTS = "CREATE_AGREEMENT";

    private String VIEW_USERS = "VIEW_USERS";
    private String CREATE_USER = "CREATE_USER";
    private String UPDATE_USER = "UPLOAD_FILE";
    private String DELETE_USER = "UPLOAD_FILE";
   
    private String VIEW_PARAMETERS = "VIEW_PARAMETERS";
    private String CREATE_PARAMETER = "CREATE_PARAMETERS";
    private String UPDATE_PARAMETER = "CREATE_AGREEMENT";
    private String DELETE_PARAMETER = "DELETE_PARAMETERS";
   
    private String VIEW_ROLES = "VIEW_ROLES";
    private String CREATE_ROLE = "CREATE_ROLE";
    private String UPDATE_ROLE = "UPDATE_ROLE";
    private String DELETE_ROLE = "DELETE_ROLE";

    private String VIEW_DOCUMENTS = "VIEW_DOCUMENTS";

    private String CREATE_PERMISSION = "CREATE_PERMISSION";
    private String UPDATE_PERMISSION = "UPDATE_PERMISSION";
    private String DELETE_PERMISSION = "DELETE_PERMISSION";
    private String VIEW_PERMISSIONS = "VIEW_PERMISSIONS";

    private String ASSIGN_PERMISSIONS_TO_ROLE = "ASSIGN_PERMISSIONS_TO_ROLE";
    private String ASSIGN_ROLES_TO_USER = "ASSIGN_ROLES_TO_USER";
}
