package com.davivienda.factoraje.constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleConstants {

    private String ROLE_ADMIN = "ROLE_ADMIN";
    private String ROLE_PAYER = "ROLE_PAYER";
    private String ROLE_PROVIDER = "ROLE_PROVIDER";
    private String ROLE_OPERATOR = "ROLE_OPERATOR";
    private String ROLE_AUTHORIZING = "ROLE_AUTHORIZING";
}