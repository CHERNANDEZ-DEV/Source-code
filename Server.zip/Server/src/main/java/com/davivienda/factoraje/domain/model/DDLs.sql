-- Tabla para 'EntityModel'
-- Almacena entidades como pagadores o proveedores.
CREATE TABLE entities (
    id UUID PRIMARY KEY,
    code VARCHAR(255),
    name VARCHAR(255),
    nit VARCHAR(255),
    account_bank VARCHAR(255),
    email VARCHAR(255),
    authentication_mode BOOLEAN, -- 0 = Conventional, 1 = Direct
    entity_type BOOLEAN
);

-- Tabla para 'PermissionModel'
-- Define los permisos granulares del sistema.
CREATE TABLE permissions (
    permission_id UUID PRIMARY KEY,
    permission_name VARCHAR(255) NOT NULL UNIQUE,
    permission_description VARCHAR(255) NOT NULL
);

-- Tabla para 'RoleModel'
-- Define los roles que agrupan varios permisos.
CREATE TABLE roles (
    role_id UUID PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL UNIQUE,
    role_description VARCHAR(255) NOT NULL
);

-- Tabla para 'ParameterModel'
-- Almacena parámetros de configuración de la aplicación.
CREATE TABLE app_parameters (
    id UUID PRIMARY KEY,
    param_key VARCHAR(255) NOT NULL UNIQUE,
    param_value VARCHAR(255) NOT NULL
);


-- =================================================================
-- 2. CREACIÓN DE TABLAS DEPENDIENTES Y TABLAS DE UNIÓN
-- =================================================================

-- Tabla para 'AgreementModel'
-- Almacena los convenios entre pagadores y proveedores.
CREATE TABLE agreements (
    agreement_id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    identifier VARCHAR(255) NOT NULL,
    -- Las siguientes columnas son claves foráneas a la tabla 'entities'.
    payer_id UUID NOT NULL,
    supplier_id UUID NOT NULL
);

-- Tabla para 'UserModel'
-- Almacena los usuarios del sistema.
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    dui VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    -- Clave foránea a la tabla 'entities'.
    entity_id UUID NOT NULL
);

-- Tabla para 'DocumentModel'
-- Almacena los documentos (facturas, etc.) transaccionados.
CREATE TABLE documents (
    document_id UUID PRIMARY KEY,
    document_number VARCHAR(20) NOT NULL UNIQUE,
    amount DOUBLE PRECISION NOT NULL,
    issue_date VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    status_update_date VARCHAR(255) NOT NULL,
    disbursement_date VARCHAR(255),
    -- Claves foráneas a otras tablas.
    proveedor_id UUID, -- Referencia a 'entities'
    acuerdo_id UUID NOT NULL, -- Referencia a 'agreements'
    cargado_por_id UUID, -- Referencia a 'users'
    seleccionado_por_id UUID, -- Referencia a 'users'
    aprobado_por_id UUID, -- Referencia a 'users'
    rechazado_por_id UUID -- Referencia a 'users'
);

-- Tabla de Unión para la relación Muchos-a-Muchos entre 'users' y 'roles'.
CREATE TABLE usuario_rol (
    usuario_id UUID NOT NULL,
    rol_id UUID NOT NULL,
    PRIMARY KEY (usuario_id, rol_id)
);

-- Tabla de Unión para la relación Muchos-a-Muchos entre 'roles' y 'permissions'.
CREATE TABLE rol_permiso (
    rol_id UUID NOT NULL,
    permiso_id UUID NOT NULL,
    PRIMARY KEY (rol_id, permiso_id)
);


-- =================================================================
-- 3. DEFINICIÓN DE CLAVES FORÁNEAS (FOREIGN KEYS)
-- Se definen al final para evitar errores de dependencias circulares.
-- =================================================================

-- Claves foráneas para la tabla 'agreements'
ALTER TABLE agreements ADD CONSTRAINT fk_agreements_payer FOREIGN KEY (payer_id) REFERENCES entities(id);
ALTER TABLE agreements ADD CONSTRAINT fk_agreements_supplier FOREIGN KEY (supplier_id) REFERENCES entities(id);

-- Clave foránea para la tabla 'users'
ALTER TABLE users ADD CONSTRAINT fk_users_entity FOREIGN KEY (entity_id) REFERENCES entities(id);

-- Claves foráneas para la tabla 'documents'
ALTER TABLE documents ADD CONSTRAINT fk_documents_supplier FOREIGN KEY (proveedor_id) REFERENCES entities(id);
ALTER TABLE documents ADD CONSTRAINT fk_documents_agreement FOREIGN KEY (acuerdo_id) REFERENCES agreements(agreement_id);
ALTER TABLE documents ADD CONSTRAINT fk_documents_uploaded_by FOREIGN KEY (cargado_por_id) REFERENCES users(id);
ALTER TABLE documents ADD CONSTRAINT fk_documents_selected_by FOREIGN KEY (seleccionado_por_id) REFERENCES users(id);
ALTER TABLE documents ADD CONSTRAINT fk_documents_approved_by FOREIGN KEY (aprobado_por_id) REFERENCES users(id);
ALTER TABLE documents ADD CONSTRAINT fk_documents_rejected_by FOREIGN KEY (rechazado_por_id) REFERENCES users(id);

-- Claves foráneas para la tabla de unión 'usuario_rol'
ALTER TABLE usuario_rol ADD CONSTRAINT fk_usuariorol_user FOREIGN KEY (usuario_id) REFERENCES users(id);
ALTER TABLE usuario_rol ADD CONSTRAINT fk_usuariorol_role FOREIGN KEY (rol_id) REFERENCES roles(role_id);

-- Claves foráneas para la tabla de unión 'rol_permiso'
ALTER TABLE rol_permiso ADD CONSTRAINT fk_rolpermiso_role FOREIGN KEY (rol_id) REFERENCES roles(role_id);
ALTER TABLE rol_permiso ADD CONSTRAINT fk_rolpermiso_permission FOREIGN KEY (permiso_id) REFERENCES permissions(permission_id);



GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO devbancaemp;

-- =================================================================
--                         FIN DEL SCRIPT
-- =================================================================