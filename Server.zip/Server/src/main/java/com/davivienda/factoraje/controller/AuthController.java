package com.davivienda.factoraje.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.Auth.LoginDTORequest;
import com.davivienda.factoraje.domain.dto.Auth.LoginDTOResponse;
import com.davivienda.factoraje.domain.dto.Auth.RegisterDTORequest;
import com.davivienda.factoraje.domain.dto.Auth.RegisterDTOResponse;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.exception.InvalidCredentialsException;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.service.AuthService;
import com.davivienda.factoraje.service.JwtService;
import com.davivienda.factoraje.service.UserService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class AuthController {

    private final AuthService authService;
    private final UserService userService;
    private final EntornoController entornoController;
    private static final Logger logger = LoggerFactory.getLogger(EntornoController.class);

    public AuthController(AuthService authService, UserService userService, EntornoController entornoController) {
        this.authService = authService;
        this.userService = userService;
        this.entornoController = entornoController;
    }

    @PostMapping("/linkUser")
    public ResponseEntity<RegisterDTOResponse> linkUser(@RequestBody RegisterDTORequest linkRequest) {
        return ResponseEntity.ok(authService.linkUser(linkRequest));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDTORequest loginRequest, HttpServletResponse response) {

        logger.info("Iniciando proceso de autenticacion");
        // Validación con BEL
        if (!true) {
            logger.info("Inicio de sesión fallido por credenciales invalidas");
            throw new InvalidCredentialsException("Credenciales invalidas");
        } 

        authService.login(loginRequest.getDui(), response);
        return ResponseEntity.ok("Login exitoso");
    }

    
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletResponse response) {
        authService.logout(response);
        return ResponseEntity.ok("Sesión cerrada");
    }

    @GetMapping("/getAllUsers")
    public ResponseEntity<List<UserModel>> getAllUsers() {
        return ResponseEntity.ok(authService.getAllUsers());
    }

}
