package com.davivienda.factoraje.enums;

public enum RoutePermission {

    // PERMISOS DE VISUALIZACIÓN DE RUTAS
    DASHBOARD_VIEW,             // Permiso para ver el dashboard de administración
    LINK_USER_VIEW,             // Permiso para ver la gestión de usuarios
    AGREEMENT_MANAGEMENT_VIEW,  // Permiso para ver la gestión de acuerdos
    PAYER_MANAGEMENT_VIEW,      // Permiso para ver la gestión de pagadores
    SUPPLIER_MANAGEMENT_VIEW,   // Permiso para ver la gestión de proveedores
    UPLOAD_FILE_VIEW,           // Permiso para ver la carga de archivos
    SELECT_DOCUMENTS_VIEW,      // Permiso para ver la pagina de selección de documentos
    DOCUMENTS_SELECTED_VIEW,    // Permiso para ver la pagina de documentos seleccionados
    APPROVE_DOCUMENTS_VIEW,     // Permiso para ver la pagina de aprobación de documentos
    DOCUMENTS_APPROVED_VIEW,    // Permiso para ver la pagina de documentos aprobados

    // PERMISOS DE EJECUCIÓN DE ACCIONES
    CREATE_PAYER_EXECUTE,       // Permiso para crear un pagador
    LINK_USER_EXECUTE,          // Permiso para vincular un usuario a un rol
    UPLOAD_DOCUMENTS_EXECUTE,   // Permiso para subir documentos
    APPROVE_DOCUMENTS_EXECUTE,  // Permiso para aprobar documentos
    SELECT_DOCUMENTS_EXECUTE,   // Permiso para seleccionar documentos
    SELECT_AGREEMENT_EXECUTE    // Permiso para seleccionar un acuerdo
    
}
