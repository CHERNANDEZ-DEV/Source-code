package com.davivienda.factoraje.controller;

import java.io.IOException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.davivienda.factoraje.service.ProcessFileService;

// Importación corregida para Spring Boot 2 (javax)
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/archivos")
@CrossOrigin(origins = "*")
public class ProcessFileController {

    private final ProcessFileService processFileService;

    @Autowired
    public ProcessFileController(ProcessFileService processFileService) {
        this.processFileService = processFileService;
    }

    @PostMapping("/upload-excel")
    public ResponseEntity<?> uploadExcelFile(
            @RequestParam("file") @NotNull MultipartFile file,
            @RequestParam("payerId") @NotNull UUID payerId,
            @RequestParam("userId") @NotNull UUID userId) {

        // Validaciones básicas del archivo
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Por favor, seleccione un archivo para cargar.");
        }

        String contentType = file.getContentType();
        if (contentType == null ||
                (!contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") &&
                        !contentType.equals("application/vnd.ms-excel"))) {
            return ResponseEntity.badRequest().body("Solo se permiten archivos Excel (.xlsx, .xls)");
        }

        try {
            String mensaje = processFileService.procesarYGuardarExcel(file, payerId, userId);
            return ResponseEntity.ok().body(mensaje);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                    .body("Error procesando el archivo: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body("Error inesperado: " + e.getMessage());
        }
    }
}