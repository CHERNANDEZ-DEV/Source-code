package com.davivienda.factoraje.service;

import java.util.List;

import javax.swing.text.Document;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.repository.DocumentRepository;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;

    public DocumentService(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    public DocumentModel createDocument(DocumentModel document) {
        if (document == null) {
            throw new IllegalArgumentException("El documento no puede ser nulo");
        }
        
        return documentRepository.save(document);
    }

    public List<DocumentModel> getAllDocuments() {
        return documentRepository.findAll();
    }
}
