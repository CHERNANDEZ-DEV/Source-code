package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.Roles.AssignPermissionsDTO;
import com.davivienda.factoraje.domain.dto.Users.AssignRolesToUserRequestDTO;
import com.davivienda.factoraje.domain.dto.Users.CreateAdminRequestDTO;
import com.davivienda.factoraje.domain.dto.Users.CreateAdminResponseDTO;
import com.davivienda.factoraje.domain.dto.Users.LoginAdminRequestDTO;
import com.davivienda.factoraje.domain.model.RoleModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.service.UserService;
import com.davivienda.factoraje.utils.JwtUtil;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import javax.servlet.http.Cookie; // <- Cambio clave: usar javax
import javax.servlet.http.HttpServletRequest; // <- Cambio clave: usar javax
import java.util.Arrays;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private static final Logger logger = LoggerFactory.getLogger(EntornoController.class);

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/createPayer")
    public ResponseEntity<UserModel> createPayer(@RequestBody UserModel payer) {
        
        return ResponseEntity.ok(userService.createPayer(payer));
    }

    @PostMapping("/assignRolesToUser")
    public ResponseEntity<UserModel> assignRolesToUser(@RequestBody AssignRolesToUserRequestDTO assignRolesToUserRequestDTO) {

        return ResponseEntity.ok(userService.assignRolesToUser(assignRolesToUserRequestDTO));
    }

    @PostMapping("/registerAdmin")
    public ResponseEntity<CreateAdminResponseDTO> registerAdmin(@RequestBody CreateAdminRequestDTO admin) {

        if (admin.getName() == null || admin.getEmail() == null || admin.getPassword() == null) {
            return ResponseEntity.badRequest()
                    .body(new CreateAdminResponseDTO("Invalid input", "Invalid input"));
        }

        return ResponseEntity.ok(userService.registerAdmin(admin));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<UserModel>> getAll() {

        return ResponseEntity.ok(userService.getAll());
    }

    @GetMapping("/getPayers")
    public ResponseEntity<List<UserModel>> getPayers() {

        return ResponseEntity.ok(userService.getPayers());
    }

    @GetMapping("/user")
    public ResponseEntity<UserModel> getUserData(HttpServletRequest request) {

        logger.info("Recibiendo petición para obtener información del usuario");

        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return ResponseEntity.status(401).build(); 
        }

        Optional<String> tokenOptional = Arrays.stream(cookies)
                .filter(c -> "token".equals(c.getName()))
                .map(Cookie::getValue)
                .findFirst();

        if (!tokenOptional.isPresent() || !JwtUtil.validateToken(tokenOptional.get())) {
            return ResponseEntity.status(401).build();
        }

        String token = tokenOptional.get();
        String DUI = JwtUtil.getDUIFromToken(token);
        System.out.println("DUI from token: " + DUI);

        logger.info("Retornando información del usuario");    
        UserModel user = userService.findUserByDUI(DUI).orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con DUI" + DUI));
            return ResponseEntity.ok(user);
        }
}
