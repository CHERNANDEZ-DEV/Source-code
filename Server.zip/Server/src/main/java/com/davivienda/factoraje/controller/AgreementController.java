package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.Documents.UpdateDocumentsRequestDTO;
import com.davivienda.factoraje.domain.model.AgreementModel;
import com.davivienda.factoraje.service.AgreementService;

@RestController
@RequestMapping("/api/agreement")
public class AgreementController {

    private final AgreementService agreementService;

    public AgreementController(AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/getAll")
    public ResponseEntity<List<AgreementModel>> getAll() {
        return ResponseEntity.ok(agreementService.findAll());
    }

    // Obtener el acuerdo y sus documentos sin importar el estado
    @CrossOrigin(origins = "*")
    @GetMapping("/byPayer/{payerId}")
    public ResponseEntity<?> getByPayer(@PathVariable String payerId) {
        try {
            if (payerId == null || payerId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("payerId no puede estar vacío");
            }

            List<AgreementModel> agreements = agreementService.findByPayer(payerId);

            if (agreements.isEmpty()) {
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(agreements);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    // Obtener el acuerdo y sus documentos con estado "SELECTED"
    @CrossOrigin(origins = "*")
    @GetMapping("/byPayer/{payerId}/{status}")
    public ResponseEntity<?> getByPayerWithStatus(@PathVariable String payerId, @PathVariable String status) {
        try {
            if (payerId == null || payerId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("payerId no puede estar vacío");
            }

            if (status == null || status.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("status no puede estar vacío");
            }

            List<AgreementModel> agreements = agreementService.findByPayerWithStatus(payerId, status);

            if (agreements.isEmpty()) {
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(agreements);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/bySupplier/{supplierId}/{status}")
    public ResponseEntity<?> getBySupplierWithStatus(@PathVariable String supplierId, @PathVariable String status) {
        try {
            if (supplierId == null || supplierId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("payerId no puede estar vacío");
            }

            if (status == null || status.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("status no puede estar vacío");
            }

            List<AgreementModel> agreements = agreementService.findBySupplierWithStatus(supplierId, status);

            if (agreements.isEmpty()) {
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(agreements);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/bySupplier/{supplierId}")
    public ResponseEntity<?> getBySupplier(@PathVariable String supplierId) {
        try {
            if (supplierId == null || supplierId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("payerId no puede estar vacío");
            }

            List<AgreementModel> agreements = agreementService.findBySupplier(supplierId);

            if (agreements.isEmpty()) {
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(agreements);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/updateDocuments/{agreementId}/{status}")
    public ResponseEntity<?> updateDocuments(@PathVariable String agreementId, @PathVariable String status,
            @RequestBody UpdateDocumentsRequestDTO documentIds) {
        try {
            if (agreementId == null || agreementId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("payerId no puede estar vacío");
            }

            if (status == null || status.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("status no puede estar vacío");
            }

            AgreementModel agreement = agreementService.updateDocuments(agreementId, status, documentIds);

            return ResponseEntity.ok(agreement);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/byId/{id}/{status}")
    public ResponseEntity<?> getByIdAndStatus(@PathVariable UUID id, @PathVariable String status) {
        try {
            if (id == null) {
                return ResponseEntity.badRequest().body("id no puede ser nulo");
            }
            AgreementModel agreement = agreementService.findByIdAndStatus(id, status);
            if (agreement == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(agreement);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/byId/{id}")
    public ResponseEntity<?> getById(@PathVariable UUID id) {
        try {
            if (id == null) {
                return ResponseEntity.badRequest().body("id no puede ser nulo");
            }
            AgreementModel agreement = agreementService.findById(id);
            if (agreement == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(agreement);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al procesar la solicitud");
        }
    }

}
