package com.davivienda.factoraje.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.Roles.AssignPermissionsDTO;
import com.davivienda.factoraje.domain.dto.Roles.RoleRequestDTO;
import com.davivienda.factoraje.domain.dto.Roles.RoleResponseDTO;
import com.davivienda.factoraje.domain.model.RoleModel;
import com.davivienda.factoraje.service.RoleService;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @RequestMapping("/getAll")
    public ResponseEntity<List<RoleResponseDTO>> getAllRoles() {
        return ResponseEntity.ok(roleService.getAllRoles());
    }

    @PostMapping("/create")
    public ResponseEntity<RoleResponseDTO> createRole(@RequestBody RoleRequestDTO roleRequestDTO) {
        RoleResponseDTO createdRole = roleService.createRole(roleRequestDTO);
        return ResponseEntity.ok(createdRole);
    }

    @PostMapping("/assignPermissions")
    public ResponseEntity<RoleModel> assignPermissionsToRole(@RequestBody AssignPermissionsDTO assignPermissionsDTO) {
        
        return ResponseEntity.ok(roleService.assignPermissionsToRole(assignPermissionsDTO)); 
    }

    @GetMapping("/createAdminRole")
    public ResponseEntity<RoleModel> createAdminRole() {
        RoleModel adminRole = roleService.createAdminRole();
        return ResponseEntity.ok(adminRole);
    }
}
