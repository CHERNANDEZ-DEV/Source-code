package com.davivienda.factoraje.utils;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class PasswordGenerator {

    private static final String LOWERCASE_CHARS = "abcdefghijklmnopqrstuvwxyz";
    private static final String UPPERCASE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGIT_CHARS = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$&()-=+[{}]:;',.<>/?"; // Puedes ajustar los caracteres especiales

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    public static String generateSecurePassword(int length,
                                                boolean includeUppercase,
                                                boolean includeLowercase,
                                                boolean includeDigits,
                                                boolean includeSpecial) {

        List<String> charCategories = new ArrayList<>();
        
        if (includeUppercase) charCategories.add(UPPERCASE_CHARS);
        if (includeLowercase) charCategories.add(LOWERCASE_CHARS);
        if (includeDigits) charCategories.add(DIGIT_CHARS);
        if (includeSpecial) charCategories.add(SPECIAL_CHARS);

        if (charCategories.isEmpty()) {
            throw new IllegalArgumentException("Debe seleccionar al menos un tipo de carácter para la contraseña.");
        }

        if (length < charCategories.size()) {
            throw new IllegalArgumentException("La longitud de la contraseña debe ser al menos igual al número de tipos de caracteres requeridos.");
        }

        StringBuilder passwordBuilder = new StringBuilder(length);
        List<Character> passwordChars = new ArrayList<>();

        // Asegurar al menos un carácter de cada tipo requerido
        for (String category : charCategories) {
            passwordChars.add(category.charAt(SECURE_RANDOM.nextInt(category.length())));
        }

        // Rellenar el resto de la contraseña con caracteres aleatorios de todas las categorías seleccionadas
        String allAllowedChars = charCategories.stream().collect(Collectors.joining());
        for (int i = passwordChars.size(); i < length; i++) {
            passwordChars.add(allAllowedChars.charAt(SECURE_RANDOM.nextInt(allAllowedChars.length())));
        }

        // Mezclar los caracteres para evitar patrones predecibles
        Collections.shuffle(passwordChars, SECURE_RANDOM);

        // Construir la contraseña final
        for (char c : passwordChars) {
            passwordBuilder.append(c);
        }

        return passwordBuilder.toString();
    }
}