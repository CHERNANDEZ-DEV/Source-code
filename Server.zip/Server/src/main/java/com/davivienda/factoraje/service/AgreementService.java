package com.davivienda.factoraje.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.Documents.UpdateDocumentsRequestDTO;
import com.davivienda.factoraje.domain.model.AgreementModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.repository.AgreementRepository;

@Service
public class AgreementService {

    private final AgreementRepository agreementRepository;

    public AgreementService(AgreementRepository agreementRepository) {
        this.agreementRepository = agreementRepository;
    }

    public List<AgreementModel> findAll() {
        return agreementRepository.findAll();
    }

    public AgreementModel findById(UUID id) {
        if (id == null) {
            throw new IllegalArgumentException("id cannot be null");
        }

        return agreementRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Agreement not found"));
    }

    public AgreementModel findByIdentifier(String code) {
        return agreementRepository.findByIdentifier(code);
    }

    public AgreementModel save(AgreementModel agreement) {
        return agreementRepository.save(agreement);
    }

    public List<AgreementModel> findByPayer(String payerId) {
        if (payerId == null) {
            throw new IllegalArgumentException("payerId cannot be null");
        }

        return agreementRepository.findAll().stream()
                .filter(agreement -> {
                    String identifier = agreement.getIdentifier();
                    return identifier != null &&
                            identifier.length() >= 36 &&
                            identifier.substring(0, 36).equals(payerId);
                })
                .collect(Collectors.toList());
    }

    public List<AgreementModel> findByPayerWithStatus(String payerId, String status) {
        if (payerId == null || status == null) {
            throw new IllegalArgumentException("payerId cannot be null or status cannot be null");
        }

        List<AgreementModel> agreements = agreementRepository.findAll().stream()
                .filter(agreement -> {
                    String identifier = agreement.getIdentifier();
                    return identifier != null &&
                            identifier.length() >= 36 &&
                            identifier.substring(0, 36).equals(payerId);
                })
                .collect(Collectors.toList());

        for (AgreementModel agreement : agreements) {
            List<DocumentModel> documents = new ArrayList<>();
            for (DocumentModel document : agreement.getDocuments()) {
                if (document.getStatus() != null && document.getStatus().equals(status)) {
                    documents.add(document);
                }
            }
            agreement.setDocuments(documents);
        }

        return agreements;
    }

    public List<AgreementModel> findBySupplierWithStatus(String supplierId, String status) {
        if (supplierId == null || status == null) {
            throw new IllegalArgumentException("supplierId cannot be null or status cannot be null");
        }

        List<AgreementModel> agreements = agreementRepository.findAll().stream()
                .filter(agreement -> {
                    String identifier = agreement.getIdentifier();
                    return identifier != null &&
                            identifier.length() >= 36 &&
                            identifier.substring(36).equals(supplierId);
                })
                .collect(Collectors.toList());

        for (AgreementModel agreement : agreements) {
            List<DocumentModel> documents = new ArrayList<>();
            for (DocumentModel document : agreement.getDocuments()) {
                if (document.getStatus() != null && document.getStatus().equals(status)) {
                    documents.add(document);
                }
            }
            agreement.setDocuments(documents);
        }

        return agreements;
    }

    public AgreementModel updateDocuments(String agreementId, String status, UpdateDocumentsRequestDTO documentIds) {

        if (agreementId == null || status == null) {
            throw new IllegalArgumentException("agreementId cannot be null or status cannot be null");
        }

        AgreementModel agreement = agreementRepository.findById(UUID.fromString(agreementId))
                .orElseThrow(() -> new IllegalArgumentException("Agreement not found"));

        for (DocumentModel document : agreement.getDocuments()) {

            if (documentIds.getDocumentIds().contains(document.getDocument_id())) {
                document.setStatus(status);
            }
        }

        return agreementRepository.save(agreement);

    }

    public List<AgreementModel> findBySupplier(String supplierId) {
        if (supplierId == null) {
            throw new IllegalArgumentException("payerId cannot be null");
        }

        return agreementRepository.findAll().stream()
                .filter(agreement -> {
                    String identifier = agreement.getIdentifier();
                    return identifier != null &&
                            identifier.length() >= 36 &&
                            identifier.substring(36).equals(supplierId);
                })
                .collect(Collectors.toList());
    }

    public AgreementModel findByIdAndStatus(UUID id, String status) {

        if (id == null || status == null) {
            throw new IllegalArgumentException("id cannot be null or status cannot be null");
        }

        AgreementModel agreement = agreementRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Agreement not found"));

        List<DocumentModel> documents = new ArrayList<>();
        for (DocumentModel document : agreement.getDocuments()) {
            if (document.getStatus() != null && document.getStatus().equals(status)) {
                documents.add(document);
            }
        }
        agreement.setDocuments(documents);

        return agreement;
    }
}