package com.davivienda.factoraje.service;

import java.security.Permission;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.management.relation.Role;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.Permissions.PermissionResponseDTO;
import com.davivienda.factoraje.domain.dto.Roles.AssignPermissionsDTO;
import com.davivienda.factoraje.domain.dto.Roles.RoleRequestDTO;
import com.davivienda.factoraje.domain.dto.Roles.RoleResponseDTO;
import com.davivienda.factoraje.domain.model.PermissionModel;
import com.davivienda.factoraje.domain.model.RoleModel;
import com.davivienda.factoraje.repository.RoleRepository;
import com.davivienda.factoraje.constants.RoleConstants;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    private final PermissionService permissionService;

    public RoleService(RoleRepository roleRepository, PermissionService permissionService) {
        this.roleRepository = roleRepository;
        this.permissionService = permissionService;
    }

    public RoleModel getRoleById(UUID roleId) {
        return roleRepository.findById(roleId)
                .orElseThrow(() -> new RuntimeException("Role not found"));
    }

    public RoleModel getRoleByName(String roleName) {
        return roleRepository.findByRoleName(roleName);
    }

    public RoleModel assignPermissionsToRole(AssignPermissionsDTO assignPermissionsDTO) {

        RoleModel role = roleRepository.findById(assignPermissionsDTO.getRole_id())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        for (UUID permissionId : assignPermissionsDTO.getPermissions()) {

            PermissionModel permission = permissionService.getPermissionById(permissionId);

            if (permission != null) {
                role.getPermisos().add(permission);
            } else {
                throw new RuntimeException("Permission with ID " + permissionId + " not found");
            }
        }

        RoleModel updatedRole = roleRepository.save(role);

        return updatedRole;
    }

    public List<RoleResponseDTO> getAllRoles() {
        List<RoleModel> roles = roleRepository.findAll();
        return roles.stream().map(role -> {
            RoleResponseDTO response = new RoleResponseDTO();
            response.setRole_id(role.getRoleId());
            response.setRoleName(role.getRoleName());
            response.setRoleDescription(role.getRoleDescription());
            response.setPermissions(role.getPermisos());
            // Assuming permissions are handled elsewhere or not needed here
            return response;
        }).collect(Collectors.toList());
    }

    public RoleResponseDTO createRole(RoleRequestDTO roleRequestDTO) {

        RoleModel roleModel = new RoleModel();

        roleModel.setRoleName(roleRequestDTO.getRoleName());
        roleModel.setRoleDescription(roleRequestDTO.getRoleDescription());

        RoleModel savedRole = roleRepository.save(roleModel);
        RoleResponseDTO roleResponseDTO = new RoleResponseDTO();
        roleResponseDTO.setRole_id(savedRole.getRoleId());
        roleResponseDTO.setRoleName(savedRole.getRoleName());
        roleResponseDTO.setRoleDescription(savedRole.getRoleDescription());

        return roleResponseDTO;
    }


    public RoleModel createAdminRole() {

        RoleConstants roleConstants = new RoleConstants();

        RoleModel adminRole = new RoleModel();
        adminRole.setRoleName(roleConstants.getROLE_ADMIN());
        adminRole.setRoleDescription("Administrator role with all permissions except for assigning roles to other users");
        
        return roleRepository.save(adminRole);
    }
}
